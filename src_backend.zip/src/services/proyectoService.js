/**
 * Servicio para manejar la lógica de negocio relacionada con proyectos.
 * @class
 */
import ProyectoRepository from '../repositories/proyectoRepository.js';
import ApiError from '../utils/ApiError.js';
import Proyecto from '../models/Proyecto.js';

class ProyectoService {
  /**
   * @param {ProyectoRepository} proyectoRepository - Inyectamos el repositorio como dependencia.
   */
  constructor(proyectoRepository) {
    this.proyectoRepository = proyectoRepository;
  }

  /**
   * Crea un nuevo proyecto después de validar los datos.
   * @async
   * @param {Object} proyectoData - Datos del proyecto { nombre, descripcion }.
   * @returns {Promise<Object>} - Proyecto creado con ID.
   */
  async crearProyecto(proyectoData) {
    // Validación a través del modelo
    const datosValidados = Proyecto.validateCreate(proyectoData);
    const proyecto = await this.proyectoRepository.crearProyecto(datosValidados);
    return proyecto.toAPI();

  }

  /**
   * Obtiene un proyecto por su ID.
   * @async
   * @param {number} id - ID del proyecto a obtener.
   * @returns {Promise<Object>} El proyecto encontrado.
   * @throws {ApiError} Si el proyecto no se encuentra.
   */
  async obtenerProyecto(id) {
    const proyecto = await this.proyectoRepository.obtenerProyectoPorId(id);
    
    if (!proyecto) {
      throw new ApiError('Proyecto no encontrado', 404);
    }
    
    return proyecto.toAPI();
  }
  
  /**
   * Actualiza un proyecto existente.
   * @async
   * @param {number} id - ID del proyecto a actualizar.
   * @param {Object} proyectoData - Datos a actualizar.
   * @returns {Promise<Object>} El proyecto actualizado.
   * @throws {ApiError} Si el proyecto no se encuentra.
   */
  async actualizarProyecto(id, proyectoData) {
    const datosValidados = Proyecto.validateUpdate(proyectoData);
    const proyecto = await this.proyectoRepository.actualizarProyecto(id, datosValidados);
    if (!proyecto) {
      throw new ApiError('Proyecto no encontrado', 404);
    }
    
    return proyecto.toAPI();
  }

  /**
   * Elimina un proyecto existente.
   * @async
   * @param {number} id - ID del proyecto a eliminar.
   * @returns {Promise<Object>} El proyecto eliminado.
   * @throws {ApiError} Si el proyecto no se encuentra.
   */
  async eliminarProyecto(id) {
    const deleted = await this.proyectoRepository.eliminarProyecto(id);
    
    if (!deleted) {
      throw new ApiError('Proyecto no encontrado', 404);
    }
    
    return deleted.toAPI();
  }

  /**
   * Lista todos los proyectos, opcionalmente filtrados por estado.
   * @async
   * @param {string} [estado] - Estado para filtrar los proyectos.
   * @returns {Promise<Array>} Lista de proyectos.
   */
  async listarProyectos(estado) {
    const proyectos = await this.proyectoRepository.listarProyectos(estado);
    return proyectos.map(proyecto => proyecto.toAPI());
  }
}
export default ProyectoService;